package com.akexorcist.localizationactivity.core;

import android.app.Activity;

/**
 * Created by Aleksander Mielczarek on 03.04.2016.
 */


/**
 * Use LocalizationActivityDelegate
 */

@Deprecated
public class LocalizationDelegate extends LocalizationActivityDelegate {
    public LocalizationDelegate(Activity activity) {
        super(activity);
    }
}
